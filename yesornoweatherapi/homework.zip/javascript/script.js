/* YOU ARE IN: yesornoweatherapi/javascript/script.js */
var city = "nyc";
var country = "us";
var temp = ""
var url = 'http://api.openweathermap.org/data/2.5/weather?q='+city+',%20'+country;

function gunsOut( temp ) { 
		console.log( temp );
		if (temp >= 1)
		{
			$( ".yes" ).addClass ( "outsideTemp")
			$( ".no" ).addClass ( "notTemp" )
		}
		else {
			$( ".yes" ).addClass ( "notTemp" )
			$( ".no" ).addClass ( "insideTemp" )
		}
	}

function loopTransition () {
	if (textColor == "purple") {
	}
}

	$.ajax( 
		{
			url: url
			, dataType: 'jsonp'
			, success: function( data ) {
        console.log( data );
        var temp = data.main.temp;
        console.log( "temp" );
        gunsOut ( temp );
      }
    }

);